package com.example.soapmvn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapmvnApplicationTests {

	@Test
	void contextLoads() {
	}

}
