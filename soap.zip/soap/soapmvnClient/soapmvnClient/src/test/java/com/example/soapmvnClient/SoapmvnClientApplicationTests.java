package com.example.soapmvnClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapmvnClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
