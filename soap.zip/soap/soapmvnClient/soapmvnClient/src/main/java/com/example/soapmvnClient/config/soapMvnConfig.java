package com.example.soapmvnClient.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
public  class soapMvnConfig {

    @Bean
    public Jaxb2Marshaller SoapMvnmarshaller() {
        Jaxb2Marshaller marshaller=new Jaxb2Marshaller();
        marshaller.setPackagesToScan("com.example.soapmvnClient.soapmvn_bindingClass");
        return marshaller;
    }

}
