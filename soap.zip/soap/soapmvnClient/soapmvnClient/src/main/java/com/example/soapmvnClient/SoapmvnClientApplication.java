package com.example.soapmvnClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapmvnClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapmvnClientApplication.class, args);
	}

}
