package com.example.soapmvnClient.controller;

import com.example.soapmvnClient.clinet.SoapClient.SoapMvnClient;
import com.example.soapmvnClient.soapmvn_bindingClass.GetUserRequest;
import com.example.soapmvnClient.soapmvn_bindingClass.GetUserResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
//@Res
public class soapClientController {

    @Autowired
    SoapMvnClient soapmvnclient;

    @PostMapping ("/display")
    public GetUserResponse display(@RequestBody  GetUserRequest request){
        System.out.println("controller called aaaaaaaaa");
        GetUserResponse response = soapmvnclient.getLoanStatus(request);
        System.out.println("response is 22222222 :" + response);
        return response;
    }
}
